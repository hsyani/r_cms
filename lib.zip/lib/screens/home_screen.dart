// /lib/screens/report_screen.dart
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('보고서'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildReportItem(
              context,
              icon: Icons.science,
              title: '화학물질 관리대장',
            ),
            _buildReportItem(
              context,
              icon: Icons.ac_unit,
              title: '특별관리물질 관리대장',
            ),
            _buildReportItem(
              context,
              icon: Icons.calendar_today,
              title: '월간시약 관리대장',
            ),
            _buildReportItem(
              context,
              icon: Icons.warning,
              title: '유해인자 취급 및 관리대장',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportItem(BuildContext context,
      {required IconData icon, required String title}) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Icon(icon, size: 40),
        title: Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () {
          // 각 보고서로 이동하는 코드를 추가할 수 있습니다.
        },
      ),
    );
  }
}
